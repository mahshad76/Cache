#include <iostream>
#include <fstream>
#include <cstdlib>
#include<conio.h>
#include <cmath>
#include<stdio.h>
#include <unistd.h>
using namespace std;

 using namespace std;
 

int convertBinaryToDecimal(long long);
int main()

{

int KK=0;
int true22=0;	
int SS=0;		
char* lru1[15];	
char str[32];	
char buffer[32];
int L1=1;
int true11=0;
int find=0;
char* lru[15];
int true1=0;
int true2=0;
int L=1;
int S=0;
int K=0;
int g=0;
int truth=0;
int gg=0;	
int miss=0;
int hit=0;
char* v[16];
for(int l=1;l<=16;l++){
	v[l]="00000000000000000000000000000000";
}
int flag_victim[16];
for(int i=1;i<=16;i++){
	flag_victim[i]=0;
}
		
 int c=0;
int dec=0;	
char tag[24];
char index[8];
	
	std::fstream f;
    f.open("nnaa.txt");
    if (!f.is_open())
    {
        
        std::cout << "Error opening file..." << std::endl;
        return -1;
    }   else std::cout << "File opened." << std::endl;
    f.close();
    
int address [32]; 
long int decimal[100];

for(int i=1;i<=100;i++)
{

	
for( c=0;c<=31;c++){
	address[c]=	rand() % 2;
	
dec=dec+pow(2,address[c]);
	
std::ofstream ofile;
ofile.open("nnaa.txt", std::ios::app);
ofile << address[c] ;
ofile.close();

}
 decimal[i]=dec;





 

std::ofstream ofile;
ofile.open("nnaa.txt", std::ios::app);
ofile << "\n  " ;
ofile.close();

	

//}
//for(int t=1;t<=100;t++){
//	printf("%lu",decimal[t]);
//	printf("\n");
}
long int locality [500];

for(int kk=1;kk<=500;kk++){
	
	
	int x=(rand()%100)+1;



	locality[kk]=decimal[x];

		for(int ii=1;ii<=100;ii++){
		if((0<=(locality[kk]-decimal[ii]) && ((locality[kk]-decimal[ii])<=60) ) || ((0<=decimal[ii]-locality[kk]) && (decimal[ii]-locality[kk]<=60) )){
			kk=kk+1;
			if(kk<=500)
			locality[kk]=decimal[ii];}}}


	
	long int cpu_address[500];
	for(int uu=1;uu<=500;uu++){
		cpu_address[uu]=locality[uu]/16;
		printf("%lu",cpu_address[uu]);
		printf("\n");
		
	}
	char* cpu[256][3];
	for(int i=1;i<=256;i++){
	
		for(int j=1;j<=2;j++){
			cpu[i][j]=0;
		}
	}
	int flag[256];
	for(int mm=1;mm<=256;mm++){
		flag[mm]=0;
	}
	 for(int ee=1;ee<=500;ee++){
	 int counter=0;
 	int vv=(cpu_address[ee]%256);
	 if(flag[vv]==0){
	 	miss++;
	 	
	 	long int dec=cpu_address[ee];
char bin32[]  = "00000000000000000000000000000000";
    for (int pos = 31; pos >= 0; --pos)
    {
        if (dec % 2) 
            bin32[pos] = '1';
        dec /= 2;
    }

  ////cout << "The binary of the given number is: " << bin32 << endl;
  ////printf("\n");
for( g=0;g<=23;g++){
tag[g]=bin32[g];
}
cpu[vv][1]=tag;
//printf("%s",cpu[vv][1]);
//printf("\n");
int l=0;
for( gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;
////printf("%c",index[gg]);
}
cpu[vv][2]=index;
///printf("%s",cpu[vv][2]);

 ////printf("\n");
 flag[vv]=1;   	
	
counter++;
	
  
}
if((flag[vv]!=0 )&& (counter==0)){
	
		long int dec=cpu_address[ee];
char bin32[]  = "00000000000000000000000000000000";
    for (int pos = 31; pos >= 0; --pos)
    {
        if (dec % 2) 
            bin32[pos] = '1';
        dec /= 2;
    }

 ////cout << "The binary of the given number is: " << bin32 << endl; 
  
for( g=0;g<=23;g++){
tag[g]=bin32[g];
}
if(cpu[vv][1]==tag){
////	printf("\n");
////	printf("%s","tag TRUE");
/////	printf("\n");
	

int l=0;

for( gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;
}
if(cpu[vv][2]==index){
	hit++;
}
}
//printf("miss %d",miss);
//printf("\n");
//printf("hit %d",hit);
//printf("\n");

if((cpu[vv][1]!=tag )|| (cpu[vv][2]!=index)){
//	printf("hiiiiiiiiiiiiiiiiiiiiiiiii");
		long int dec=cpu_address[ee];
char bin32[]  = "00000000000000000000000000000000";
    for (int pos = 31; pos >= 0; --pos)
    {
        if (dec % 2) 
            bin32[pos] = '1';
        dec /= 2;
    }
	for( find=1;find<=16;find++){
		if(v[find]==bin32){
			hit++;
			truth=1;
			break;
			
		}
		
	}
	if(truth==1){
		
		char buffer[32]; // <- danger, only storage for 256 characters.
strncpy(buffer, cpu[vv][1], sizeof(buffer));
strncat(buffer, cpu[vv][2], sizeof(buffer));

for( int g=0;g<=23;g++){
tag[g]=bin32[g];
}
int l=0;
for(int  gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;

}
cpu[vv][1]=tag;
cpu[vv][2]=index;

for(int kk=1;kk<=16;kk++){
	if(flag_victim[kk]==0){
		v[kk]=buffer;
		flag_victim[kk]=1;
		true1=1;
		if(L!=16){
		lru[L]=buffer;
		L++;
		break;
		
	}
	if(L==16){
		L=1;
		lru[L]=buffer;
		L++;
		break;
	}}
	
	
		
	}
	if(true1==0){
		for( S=1;S<=16;S++){
			for(K=1;K<=15;K++){
				if(v[S]==lru[K]){
					true2=1;
					break;
				}
			}
			if(true2==0){
				v[S]=buffer;
				break;
				
			}
		}
		
	}
}







if(truth==0){
	miss++;
for( int g=0;g<=23;g++){
tag[g]=bin32[g];
}
int l=0;
for(int  gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;

}
	
strncpy(str, cpu[vv][1], sizeof(buffer));
strncat(str, cpu[vv][2], sizeof(buffer));
cpu[vv][1]=tag;
cpu[vv][2]=index;
for(int kk=1;kk<=16;kk++){
	if(flag_victim[kk]==0){
		v[kk]=str;
		flag_victim[kk]=1;
		true11=1;
		if(L1!=16){
		lru1[L1]=str;
		L1++;
		break;
		
	}
	if(L1==16){
		L1=1;
		lru1[L1]=str;
		L1++;
		break;
	}}
	
	
		
	}
		if(true11==0){
		for( SS=1;SS<=16;SS++){
			for(KK=1;KK<=15;KK++){
				if(v[SS]==lru[KK]){
					true22=1;
					break;
				}
			}
			if(true22==0){
				v[SS]=str;
				break;
				
			}
		}
		
	}
}





	


	
	
}

	
	}
}
printf("miss %d",miss);
printf("\n");
printf("hit %d",hit);
printf("\n");

return 0;
}


