#include <iostream>
#include <fstream>
#include <cstdlib>
#include<conio.h>
#include <cmath>
#include<stdio.h>
#include <unistd.h>
using namespace std;

 using namespace std;
 

int convertBinaryToDecimal(long long);

int main()

{

int g=0;
int gg=0;	
int miss=0;
int hit=0;

		
 int c=0;
int dec=0;	
char tag[24];
char index[8];
	
	std::fstream f;
    f.open("nnaa.txt");
    if (!f.is_open())
    {
        
        std::cout << "Error opening file..." << std::endl;
        return -1;
    }   else std::cout << "File opened." << std::endl;
    f.close();
    
int address [32]; 
long int decimal[100];

for(int i=1;i<=100;i++)
{

	
for( c=0;c<=31;c++){
	address[c]=	rand() % 2;
	
dec=dec+pow(2,address[c]);
	
std::ofstream ofile;
ofile.open("nnaa.txt", std::ios::app);
ofile << address[c] ;
ofile.close();

}
 decimal[i]=dec;





 

std::ofstream ofile;
ofile.open("nnaa.txt", std::ios::app);
ofile << "\n  " ;
ofile.close();

	

}
//for(int t=1;t<=100;t++){
//	printf("%lu",decimal[t]);
	printf("\n");
//}
long int locality [500];

for(int kk=1;kk<=500;kk++){
	
	
	int x=(rand()%100)+1;



	locality[kk]=decimal[x];

		for(int ii=1;ii<=100;ii++){
		if((0<=(locality[kk]-decimal[ii]) && ((locality[kk]-decimal[ii])<=60) ) || ((0<=decimal[ii]-locality[kk]) && (decimal[ii]-locality[kk]<=60) )){
			kk=kk+1;
			if(kk<=500)
			locality[kk]=decimal[ii];
		////	printf("%d",locality[kk]);
		///printf("%lu",locality);
		///	printf("\n"); 
		}
	}

	}
	long int cpu_address[500];
	for(int uu=1;uu<=500;uu++){
		cpu_address[uu]=locality[uu]/16;
		printf("%lu",cpu_address[uu]);
		printf("\n");
	}
	char* cpu[256][3];
	for(int i=1;i<=256;i++){
	
		for(int j=1;j<=2;j++){
			cpu[i][j]=0;
		}
	}
	int flag[256];
	for(int mm=1;mm<=256;mm++){
		flag[mm]=0;
	}
	 for(int ee=1;ee<=500;ee++){
	 int counter=0;
 	int vv=(cpu_address[ee]%256);
	 if(flag[vv]==0){
	 	miss++;
	 	
	 	long int dec=cpu_address[ee];
char bin32[]  = "00000000000000000000000000000000";
    for (int pos = 31; pos >= 0; --pos)
    {
        if (dec % 2) 
            bin32[pos] = '1';
        dec /= 2;
    }

  ////cout << "The binary of the given number is: " << bin32 << endl;
  ////printf("\n");
for( g=0;g<=23;g++){
tag[g]=bin32[g];
}
//printf("%s",tag);
//cpu[vv][1]=tag;
//printf("%s",cpu[vv][1]);
//printf("\n");
int l=0;
for( gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;}
//printf("%s",index);


///printf("%s",cpu[vv][2]);

 printf("\n");
 flag[vv]=1;   	
	
counter++;
	
  
}
if((flag[vv]!=0 )&& (counter==0)){

		long int dec=cpu_address[ee];
char bin32[]  = "00000000000000000000000000000000";
    for (int pos = 31; pos >= 0; --pos)
    {
        if (dec % 2) 
            bin32[pos] = '1';
        dec /= 2;
    }

 ////cout << "The binary of the given number is: " << bin32 << endl; 
  
for( g=0;g<=23;g++){
tag[g]=bin32[g];
}
if(cpu[vv][1]==tag){
////	printf("\n");
////	printf("%s","tag TRUE");
/////	printf("\n");
	


int l=0;
for( gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;
}
///printf("\n");
//printf("index cpu %s",cpu[vv][2]);
//printf("\n");
//printf("tag address %s",tag);
//printf("\n");

//printf("index address %s",index);
//printf("\n");
if(cpu[vv][2]==index){
	hit++;
}


 ////printf("\n");
//// printf("%s","index TRUE");
 
//// printf("\n");	
}
for( g=0;g<=23;g++){
tag[g]=bin32[g];
}
int l=0;
for( gg=24;gg<=31;gg++){
index[l]=bin32[gg];
l++;
}

if((cpu[vv][1]!=tag )|| (cpu[vv][2]!=index)){
	miss++;
	cpu[vv][1]=tag;
	cpu[vv][2]=index;
}


	 }
	

	 
}
printf("miss %d",miss);
printf("\n");
printf("hit %d",hit);
printf("\n");


	

return 0;

}


